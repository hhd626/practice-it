/*
* Complete the following for loop to produce the following output:
* 
* -4
* 14
* 32
* 50
* 68
* 86
*/

for (int i = 1; i <= 6; i++) {
    System.out.println(-22 + 18 * i);
}

