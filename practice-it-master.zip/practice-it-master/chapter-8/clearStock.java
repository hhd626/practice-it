/*
* Resets this Stock's number of shares purchased and total cost to 0.
*/

public void clear() {
   totalShares = 0;
   totalCost = 0.0;
}
