/*
* Write a complete Java program in a class named Spikey that prints the following output:
*
*   \/
*  \\//
* \\\///
* ///\\\
*  //\\
*   /\
*/

public class Spikey{
    public static void main(String[] args){
        System.out.println("  \\/  ");
        System.out.println(" \\\\// ");
        System.out.println("\\\\\\///");
        System.out.println("///\\\\\\");
        System.out.println(" //\\\\ ");
        System.out.println("  /\\  ");
    }
}

