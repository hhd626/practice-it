/*
* Write a complete Java program in a class named Difference that prints the following output:
*
* What is the difference between
* a ' and a "?  Or between a " and a \"?
*
* One is what we see when we're typing our program.
* The other is what appears on the "console."
*/

public class Difference{
    public static void main(String[] args){
        System.out.println("What is the difference between");
        System.out.println("a ' and a \"?  Or between a \" and a \\\"?");
        System.out.println();
        System.out.println("One is what we see when we're typing our program.");
        System.out.println("The other is what appears on the \"console.\"");
    }
}

