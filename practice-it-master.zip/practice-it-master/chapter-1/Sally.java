/*
* Write series of println statements that produce the following output
* "Several slashes are sometimes seen,"
* said Sally. "I've said so." See?
* \ / \\ // \\\ ///
*/

System.out.println("\"Several slashes are sometimes seen,\"");
System.out.println("said Sally. \"I've said so.\" See?");
System.out.println("\\ / \\\\ // \\\\\\ ///");
