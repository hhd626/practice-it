practice-it
===========

This is for online practice questions from http://practiceit.cs.washington.edu/practiceit/index.jsp
